<?php 
require 'includes/header.php';
session_destroy();
?>

	<div class="user_details column">
		<a href="#"> <img src="<?php echo $user['profile_pic']; ?>"> </a>

</div>


</div>
</body>
</html>