<?php 
ob_start();
session_start();
$timezone = date_default_timezone_set("America/New_York");


$con = mysqli_connect("localhost", "rippulec_invi", "password1357", "rippulec_hcoding");
if(mysqli_connect_errno()) {
	echo "Failed to connect: mySQL database" . mysqli_connect();
}


?>
