<?php 
include("includes/header.php");
 ?>
	

	<div class="main_column column">
		This is YOUR profile page!


	</div>




	</div>
</body>
</html>