<?php
ob_start(); //Turns on output buffering 
session_start();

$timezone = date_default_timezone_set("America/New York");

$con = mysqli_connect("localhost", "rippulec_invi", "password1357", "rippulec_hcoding"); //Connection variable

if(mysqli_connect_errno()) 
{
	echo "Failed to connect: " . mysqli_connect_errno();
}

?>